# 다음과 같이 출력
# *****
# *****
# *****
# *****

for y in range(4) :
    for x in range(5) :
        i = '*'
        print(i,end='')
    print()
